public class CPU {
    public int[][] easy(int[][] gameMatrix){
        return gameMatrix;
    }
    public int[][] medium(int[][] gameMatrix){
        return gameMatrix;
    }
    public int[][] hard(int[][] gameMatrix){
        return gameMatrix;
    }
    
}
